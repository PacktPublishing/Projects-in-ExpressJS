(function (app) {
  'use strict';

  app.registerModule('jobs');
}(ApplicationConfiguration));
