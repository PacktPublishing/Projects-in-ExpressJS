require 'test_helper'

class PublishersHelperTest < ActionView::TestCase
end
