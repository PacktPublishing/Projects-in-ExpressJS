--In order to run the app, install the dependencies first with...

npm install

--Then run the dev server with

ng serve

//OR if you have nodemon installed (npm install -g nodemon)
nodemon