import { Component } from '@angular/core';

@Component({
  selector: 'clients',
  templateUrl: './clients.component.html'
})
export class ClientsComponent {
 
}
