'use strict';

module.exports = function MoviesModel() {
    return {
        name: 'movies'
    };
};
